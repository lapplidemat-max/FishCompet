import { Navigate, Route, Routes } from "react-router-dom";
import AppLayout from "./components/AppLayout";
import ProtectedRoute from "./components/ProtectedRoute";
import LoginPage from "./pages/LoginPage";
import DashboardPage from "./pages/DashboardPage";
import CatchesPage from "./pages/CatchesPage";
import AddCatchPage from "./pages/AddCatchPage";
import CompetitionsPage from "./pages/CompetitionsPage";
import CompetitionDetailsPage from "./pages/CompetitionDetailsPage";
import ProfilePage from "./pages/ProfilePage";
import NotFoundPage from "./pages/NotFoundPage";

/*
  MODIFICATION :
  - ajout de la route détail concours
  - protection des pages internes via ProtectedRoute
*/

export default function App() {
  return (
    <Routes>
      <Route path="/connexion" element={<LoginPage />} />

      <Route
        element={
          <ProtectedRoute>
            <AppLayout />
          </ProtectedRoute>
        }
      >
        <Route path="/" element={<Navigate to="/tableau-de-bord" replace />} />
        <Route path="/tableau-de-bord" element={<DashboardPage />} />
        <Route path="/captures" element={<CatchesPage />} />
        <Route path="/captures/ajouter" element={<AddCatchPage />} />
        <Route path="/concours" element={<CompetitionsPage />} />
        <Route path="/concours/:competitionId" element={<CompetitionDetailsPage />} />
        <Route path="/profil" element={<ProfilePage />} />
      </Route>

      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  );
}