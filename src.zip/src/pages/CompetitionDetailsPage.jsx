import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import {
  buildCompetitionRanking,
  fetchCompetitionById,
  fetchCompetitionCatches,
  fetchCompetitionParticipantCatches,
  fetchCompetitionParticipants,
  getCommissionStatusLabel,
  getCompetitionEntryDeadline,
  getCompetitionEntryStatus,
  getDisplayNameFromProfile,
  getOfficialCatchMetrics,
  updateCompetitionCatchCommission,
  updateCompetitionResultsRelease
} from "../services/competitions";

/*
  MODIFICATION :
  Page détail concours.
  Elle affiche :
  - le créateur du concours selon le mode choisi
  - la date de début du concours
  - la date de fin du concours
  - la date limite de saisie (fin + délai)
  - les statistiques rapides
  - le classement si autorisé
  - les captures du concours si autorisé
  - un bouton visible seulement par le créateur pour publier les résultats
    quand le concours est en mode "hidden" ET après la date limite de saisie
  - sexe, catégorie et club dans le classement
  - multi-filtres sur le classement : sexe + catégorie + club
  - outil organisateur / commissaire de vérification des fiches participant

  NOUVELLES MODIFICATIONS :
  - filtre rapide des prises participant par statut commissaire
  - bouton "Valider toutes les prises en attente"
  - boutons rapides par ligne : valider / refuser / corriger
  - affichage plus compact pour accélérer la vérification

  NOUVELLE MODIFICATION IMPORTANTE :
  - ajout d'une fiche officielle type "fiche commissaire 2022"
  - les espèces présentes sur le modèle officiel restent en haut
  - les espèces absentes du modèle sont ajoutées dans les lignes vides du bas
  - séparation automatique :
    > poissons >= 15 cm
    > poissons < 15 cm
    > grandes vives
  - les métriques officielles utilisées prennent en compte la validation commissaire
*/

const ALL_FILTER_VALUE = "__all__";

const REVIEW_STATUS_FILTERS = [
  { value: "all", label: "Toutes" },
  { value: "pending", label: "En attente" },
  { value: "validated", label: "Validées" },
  { value: "corrected", label: "Corrigées" },
  { value: "rejected", label: "Refusées" }
];

/*
  MODIFICATION :
  Lignes officielles de la fiche commissaire.
  Les espèces non prévues dans cette liste seront ajoutées dans les lignes vides.
*/
const OFFICIAL_SHEET_ROWS = [
  "BAR FRANC",
  "BAR MOUCHETÉ",
  "TURBOT ou BARBUE",
  "SOLE",
  "SAR",
  "RAYÉ",
  "GRISET",
  "DAURADE ROYALE",
  "MULET",
  "ORPHIE",
  "CARRELET ou FLET",
  "TRUITE ou SAUMON",
  "OMBRINE"
];

/*
  MODIFICATION :
  Mapping officiel basé sur les espèces du barème / variantes de saisie.
  On normalise les libellés pour supporter les différences d'accents,
  espaces, tirets ou formulations proches.
*/
const OFFICIAL_SPECIES_ALIASES = {
  "BAR FRANC": [
    "bar",
    "bar franc",
    "loup",
    "dicentrarchus labrax"
  ],
  "BAR MOUCHETÉ": [
    "bar mouchete",
    "bar moucheté"
  ],
  "TURBOT ou BARBUE": [
    "turbot",
    "barbue"
  ],
  SOLE: ["sole"],
  SAR: ["sar"],
  "RAYÉ": [
    "raye",
    "rayé"
  ],
  GRISET: ["griset"],
  "DAURADE ROYALE": [
    "daurade royale",
    "dorade royale"
  ],
  MULET: ["mulet"],
  ORPHIE: ["orphie"],
  "CARRELET ou FLET": [
    "carrelet",
    "flet"
  ],
  "TRUITE ou SAUMON": [
    "truite",
    "saumon"
  ],
  OMBRINE: ["ombrine"]
};

const GRANDE_VIVE_ALIASES = [
  "grande vive",
  "grandes vives",
  "vive",
  "vives"
];

function buildCommissionDraft(entry) {
  return {
    commissionStatus: entry?.commission_status || "pending",
    commissionValidatedLengthCm:
      entry?.commission_validated_length_cm ??
      entry?.catches?.longueur_cm ??
      "",
    commissionValidatedWeightG:
      entry?.commission_validated_weight_g ?? entry?.catches?.poids_g ?? "",
    commissionNote: entry?.commission_note || ""
  };
}

/*
  MODIFICATION :
  Normalisation d'espèce pour rendre le mapping plus robuste.
*/
function normalizeSpeciesName(value) {
  return String(value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/['’]/g, " ")
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

/*
  MODIFICATION :
  Retourne le libellé officiel de la fiche si l'espèce existe déjà
  sur le modèle FFPS.
*/
function getOfficialSheetRowLabel(speciesName) {
  const normalizedSpecies = normalizeSpeciesName(speciesName);

  if (!normalizedSpecies) {
    return null;
  }

  const isGrandeVive = GRANDE_VIVE_ALIASES.some(
    (alias) => normalizeSpeciesName(alias) === normalizedSpecies
  );

  if (isGrandeVive) {
    return "GRANDE VIVE";
  }

  for (const [officialLabel, aliases] of Object.entries(
    OFFICIAL_SPECIES_ALIASES
  )) {
    const found = aliases.some(
      (alias) => normalizeSpeciesName(alias) === normalizedSpecies
    );

    if (found) {
      return officialLabel;
    }
  }

  return null;
}

/*
  MODIFICATION :
  Prépare les données de la fiche officielle.
  - espèces officielles d'abord
  - espèces hors modèle ajoutées dans les lignes vides
  - métriques officielles basées sur les décisions commissaire
*/
function buildOfficialSheetData({ entries, drafts }) {
  const officialRowsMap = new Map(
    OFFICIAL_SHEET_ROWS.map((label) => [label, []])
  );
  const extraRowsMap = new Map();
  const under15Map = new Map();

  let measuredCount = 0;
  let measuredWeight = 0;

  let under15Count = 0;
  let under15Weight = 0;

  let grandeViveCount = 0;
  let grandeViveWeight = 0;

  let biggestFishWeight = 0;

  (entries || []).forEach((entry) => {
    const catchData = entry?.catches;

    if (!catchData) {
      return;
    }

    /*
      MODIFICATION :
      on prend en compte les brouillons organisateur en cours d'édition
      pour afficher immédiatement la fiche officielle à jour.
    */
    const draft = drafts?.[entry.id];
    const effectiveEntry = draft
      ? {
          ...entry,
          commission_status: draft.commissionStatus,
          commission_validated_length_cm: draft.commissionValidatedLengthCm,
          commission_validated_weight_g: draft.commissionValidatedWeightG,
          commission_note: draft.commissionNote
        }
      : entry;

    const officialMetrics = getOfficialCatchMetrics(effectiveEntry);

    /*
      MODIFICATION :
      une prise refusée ne compte pas sur la fiche officielle.
    */
    if (!officialMetrics) {
      return;
    }

    const speciesName = catchData.espece || "Espèce non renseignée";
    const officialLabel = getOfficialSheetRowLabel(speciesName);
    const longueurCm = Number(officialMetrics.longueurCm || 0);
    const poidsG = Number(officialMetrics.poidsG || 0);

    if (officialLabel === "GRANDE VIVE") {
      /*
        MODIFICATION :
        la grande vive est dans sa zone dédiée.
        Le modèle FFPS indique un forfait de 100 points par prise.
        On l'affiche comme valeur officielle de la zone.
      */
      grandeViveCount += 1;
      grandeViveWeight += 100;
      biggestFishWeight = Math.max(biggestFishWeight, 100);
      return;
    }

    if (longueurCm < 15) {
      const current = under15Map.get(speciesName) || {
        label: speciesName,
        count: 0,
        totalWeight: 0
      };

      current.count += 1;
      current.totalWeight += poidsG;

      under15Map.set(speciesName, current);

      under15Count += 1;
      under15Weight += poidsG;
      biggestFishWeight = Math.max(biggestFishWeight, poidsG);
      return;
    }

    if (officialLabel && officialRowsMap.has(officialLabel)) {
      officialRowsMap.get(officialLabel).push(longueurCm);
    } else {
      /*
        MODIFICATION :
        si l'espèce n'existe pas sur la feuille officielle,
        on l'ajoute dans les lignes vides du bas.
      */
      const current = extraRowsMap.get(speciesName) || [];
      current.push(longueurCm);
      extraRowsMap.set(speciesName, current);
    }

    measuredCount += 1;
    measuredWeight += poidsG;
    biggestFishWeight = Math.max(biggestFishWeight, poidsG);
  });

  const officialRows = OFFICIAL_SHEET_ROWS.map((label) => ({
    label,
    lengths: (officialRowsMap.get(label) || []).sort((a, b) => a - b)
  }));

  const extraRows = Array.from(extraRowsMap.entries())
    .map(([label, lengths]) => ({
      label,
      lengths: [...lengths].sort((a, b) => a - b)
    }))
    .sort((a, b) => a.label.localeCompare(b.label, "fr"));

  const under15Rows = Array.from(under15Map.values()).sort((a, b) =>
    a.label.localeCompare(b.label, "fr")
  );

  return {
    officialRows,
    extraRows,
    under15Rows,
    measuredCount,
    measuredWeight,
    under15Count,
    under15Weight,
    grandeViveCount,
    grandeViveWeight,
    totalFishCount: measuredCount + under15Count + grandeViveCount,
    totalWeight: measuredWeight + under15Weight + grandeViveWeight,
    biggestFishWeight
  };
}

export default function CompetitionDetailsPage() {
  const { competitionId } = useParams();
  const { user } = useAuth();

  const [competition, setCompetition] = useState(null);
  const [participants, setParticipants] = useState([]);
  const [competitionCatches, setCompetitionCatches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");
  const [publishingResults, setPublishingResults] = useState(false);

  /*
    MODIFICATION :
    Etats de filtres pour le classement.
  */
  const [selectedSexe, setSelectedSexe] = useState(ALL_FILTER_VALUE);
  const [selectedCategorie, setSelectedCategorie] = useState(ALL_FILTER_VALUE);
  const [selectedClub, setSelectedClub] = useState(ALL_FILTER_VALUE);

  /*
    MODIFICATION :
    Etats de vérification organisateur.
  */
  const [selectedParticipantId, setSelectedParticipantId] = useState("");
  const [reviewParticipantProfile, setReviewParticipantProfile] =
    useState(null);
  const [reviewEntries, setReviewEntries] = useState([]);
  const [reviewDrafts, setReviewDrafts] = useState({});
  const [reviewLoading, setReviewLoading] = useState(false);
  const [reviewSavingId, setReviewSavingId] = useState("");
  const [reviewMessage, setReviewMessage] = useState("");

  /*
    MODIFICATION :
    filtre rapide sur les lignes de la fiche participant.
  */
  const [reviewStatusFilter, setReviewStatusFilter] = useState("all");

  useEffect(() => {
    async function loadCompetitionDetails() {
      try {
        setLoading(true);
        setMessage("");

        const [competitionData, participantsData, catchesData] =
          await Promise.all([
            fetchCompetitionById(competitionId),
            fetchCompetitionParticipants(competitionId),
            fetchCompetitionCatches(competitionId)
          ]);

        setCompetition(competitionData);
        setParticipants(participantsData);
        setCompetitionCatches(catchesData);
      } catch (error) {
        setMessage(error.message || "Erreur lors du chargement du concours.");
      } finally {
        setLoading(false);
      }
    }

    loadCompetitionDetails();
  }, [competitionId]);

  /*
    MODIFICATION :
    Classement général brut, sans filtre.
  */
  const ranking = useMemo(() => {
    return buildCompetitionRanking({
      participants,
      competitionCatches,
      participantDisplayMode: competition?.participant_display_mode || "pseudo"
    });
  }, [
    participants,
    competitionCatches,
    competition?.participant_display_mode
  ]);

  /*
    MODIFICATION :
    Options disponibles pour les filtres à partir du classement réel.
  */
  const sexeOptions = useMemo(() => {
    const values = Array.from(
      new Set(
        ranking.map((row) => row.sexe).filter((value) => value && value !== "—")
      )
    );

    return values.sort((a, b) => a.localeCompare(b, "fr"));
  }, [ranking]);

  const categorieOptions = useMemo(() => {
    const values = Array.from(
      new Set(
        ranking
          .map((row) => row.categorie)
          .filter((value) => value && value !== "—")
      )
    );

    return values.sort((a, b) => a.localeCompare(b, "fr"));
  }, [ranking]);

  const clubOptions = useMemo(() => {
    const values = Array.from(
      new Set(
        ranking.map((row) => row.club).filter((value) => value && value !== "—")
      )
    );

    return values.sort((a, b) => a.localeCompare(b, "fr"));
  }, [ranking]);

  /*
    MODIFICATION :
    Application des filtres combinés.
  */
  const filteredRanking = useMemo(() => {
    return ranking.filter((row) => {
      const sexeMatches =
        selectedSexe === ALL_FILTER_VALUE || row.sexe === selectedSexe;

      const categorieMatches =
        selectedCategorie === ALL_FILTER_VALUE ||
        row.categorie === selectedCategorie;

      const clubMatches =
        selectedClub === ALL_FILTER_VALUE || row.club === selectedClub;

      return sexeMatches && categorieMatches && clubMatches;
    });
  }, [ranking, selectedSexe, selectedCategorie, selectedClub]);

  const stats = useMemo(() => {
    const catchesOnly = competitionCatches
      .map((entry) => entry.catches)
      .filter(Boolean);

    const totalCatches = catchesOnly.length;

    const totalWeight = catchesOnly.reduce((sum, catchItem) => {
      return sum + Number(catchItem.poids_g || 0);
    }, 0);

    const biggestCatch = catchesOnly.reduce((max, catchItem) => {
      return Math.max(max, Number(catchItem.poids_g || 0));
    }, 0);

    return {
      participantsCount: participants.length,
      totalCatches,
      totalWeight,
      biggestCatch
    };
  }, [participants, competitionCatches]);

  const creatorName = useMemo(() => {
    return getDisplayNameFromProfile(
      competition?.creator_profile,
      competition?.participant_display_mode || "pseudo"
    );
  }, [competition]);

  const isCreator = useMemo(() => {
    return (
      !!user?.id &&
      !!competition?.creator_id &&
      user.id === competition.creator_id
    );
  }, [user?.id, competition?.creator_id]);

  const entryDeadline = useMemo(() => {
    return getCompetitionEntryDeadline(competition);
  }, [competition]);

  /*
    MODIFICATION :
    Vérifie si le concours n'accepte plus de saisie.
  */
  const isCompetitionEntryClosed = useMemo(() => {
    if (!entryDeadline) {
      return false;
    }

    return new Date() > entryDeadline;
  }, [entryDeadline]);

  /*
    MODIFICATION :
    Les résultats sont visibles :
    - immédiatement si mode immediate
    - si results_released = true quand mode hidden
    - pour hourly on garde l'affichage visible, comme avant
  */
  const canShowResults = useMemo(() => {
    if (!competition) {
      return false;
    }

    if (competition.results_visibility === "hidden") {
      return competition.results_released === true;
    }

    return true;
  }, [competition]);

  const isHourlyVisibility = competition?.results_visibility === "hourly";

  const canCreatorPublishResults = useMemo(() => {
    return (
      isCreator &&
      isCompetitionEntryClosed &&
      competition?.results_visibility === "hidden" &&
      competition?.results_released !== true
    );
  }, [
    isCreator,
    isCompetitionEntryClosed,
    competition?.results_visibility,
    competition?.results_released
  ]);

  /*
    MODIFICATION :
    Liste des participants pour la fiche commissaire.
  */
  const reviewParticipantOptions = useMemo(() => {
    return participants
      .map((participant) => ({
        userId: participant.user_id,
        displayName: getDisplayNameFromProfile(
          participant?.profiles,
          competition?.participant_display_mode || "pseudo"
        ),
        sexe: participant?.profiles?.sexe || "—",
        categorie: participant?.profiles?.categorie || "—",
        club: participant?.profiles?.club || "—"
      }))
      .sort((a, b) => a.displayName.localeCompare(b.displayName, "fr"));
  }, [participants, competition?.participant_display_mode]);

  /*
    MODIFICATION :
    Chargement de la fiche du participant sélectionné.
  */
  useEffect(() => {
    async function loadParticipantReview() {
      try {
        if (!isCreator || !selectedParticipantId) {
          setReviewParticipantProfile(null);
          setReviewEntries([]);
          setReviewDrafts({});
          setReviewMessage("");
          setReviewStatusFilter("all");
          return;
        }

        setReviewLoading(true);
        setReviewMessage("");

        const data = await fetchCompetitionParticipantCatches(
          competitionId,
          selectedParticipantId
        );

        setReviewParticipantProfile(data.participantProfile || null);
        setReviewEntries(data.entries || []);

        const nextDrafts = {};
        (data.entries || []).forEach((entry) => {
          nextDrafts[entry.id] = buildCommissionDraft(entry);
        });
        setReviewDrafts(nextDrafts);
      } catch (error) {
        setReviewMessage(
          error.message || "Erreur lors du chargement de la fiche participant."
        );
      } finally {
        setReviewLoading(false);
      }
    }

    loadParticipantReview();
  }, [competitionId, selectedParticipantId, isCreator]);

  /*
    MODIFICATION :
    Résumé officiel de la fiche participant selon validation commissaire.
  */
  const reviewOfficialSummary = useMemo(() => {
    const acceptedEntries = reviewEntries.filter(
      (entry) =>
        entry.commission_status === "validated" ||
        entry.commission_status === "corrected"
    );

    const officialMetrics = acceptedEntries
      .map((entry) => getOfficialCatchMetrics(entry))
      .filter(Boolean);

    const totalFish = officialMetrics.length;
    const totalWeight = officialMetrics.reduce(
      (sum, metric) => sum + Number(metric.poidsG || 0),
      0
    );
    const biggestCatch = officialMetrics.reduce(
      (max, metric) => Math.max(max, Number(metric.poidsG || 0)),
      0
    );

    const pendingCount = reviewEntries.filter(
      (entry) => entry.commission_status === "pending"
    ).length;

    const rejectedCount = reviewEntries.filter(
      (entry) => entry.commission_status === "rejected"
    ).length;

    const correctedCount = reviewEntries.filter(
      (entry) => entry.commission_status === "corrected"
    ).length;

    const validatedCount = reviewEntries.filter(
      (entry) => entry.commission_status === "validated"
    ).length;

    return {
      totalFish,
      totalWeight,
      biggestCatch,
      pendingCount,
      rejectedCount,
      correctedCount,
      validatedCount
    };
  }, [reviewEntries]);

  /*
    MODIFICATION :
    fiche officielle FFPS calculée avec les brouillons en cours.
  */
  const officialSheetData = useMemo(() => {
    return buildOfficialSheetData({
      entries: reviewEntries,
      drafts: reviewDrafts
    });
  }, [reviewEntries, reviewDrafts]);

  /*
    MODIFICATION :
    filtre rapide sur les lignes de la fiche participant.
  */
  const filteredReviewEntries = useMemo(() => {
    if (reviewStatusFilter === "all") {
      return reviewEntries;
    }

    return reviewEntries.filter(
      (entry) => entry.commission_status === reviewStatusFilter
    );
  }, [reviewEntries, reviewStatusFilter]);

  async function handlePublishResults() {
    try {
      if (!competition?.id) {
        return;
      }

      setPublishingResults(true);
      setMessage("");

      const updatedCompetition = await updateCompetitionResultsRelease({
        competitionId: competition.id,
        resultsReleased: true
      });

      setCompetition((prev) => ({
        ...prev,
        ...updatedCompetition
      }));
    } catch (error) {
      setMessage(error.message || "Erreur lors de la publication des résultats.");
    } finally {
      setPublishingResults(false);
    }
  }

  function getStatusLabel() {
    const status = getCompetitionEntryStatus(competition);

    if (status === "pas_commence") {
      return "Pas encore commencé";
    }

    if (status === "delai_saisie") {
      return "Fin de pêche passée, délai de saisie en cours";
    }

    if (status === "termine") {
      return "Terminé";
    }

    if (status === "en_cours") {
      return "En cours";
    }

    return "Dates à vérifier";
  }

  /*
    MODIFICATION :
    Permet de remettre les filtres à zéro.
  */
  function resetFilters() {
    setSelectedSexe(ALL_FILTER_VALUE);
    setSelectedCategorie(ALL_FILTER_VALUE);
    setSelectedClub(ALL_FILTER_VALUE);
  }

  /*
    MODIFICATION :
    Mise à jour locale des brouillons commissaire.
  */
  function handleReviewDraftChange(entryId, field, value) {
    setReviewDrafts((prev) => ({
      ...prev,
      [entryId]: {
        ...prev[entryId],
        [field]: value
      }
    }));
  }

  /*
    MODIFICATION :
    Sauvegarde commissaire d'une prise.
  */
  async function handleSaveCommission(entryId) {
    try {
      if (!user?.id) {
        return;
      }

      const draft = reviewDrafts[entryId];

      if (!draft) {
        return;
      }

      setReviewSavingId(entryId);
      setReviewMessage("");

      const updatedRow = await updateCompetitionCatchCommission({
        competitionCatchId: entryId,
        commissionStatus: draft.commissionStatus,
        commissionValidatedLengthCm: draft.commissionValidatedLengthCm,
        commissionValidatedWeightG: draft.commissionValidatedWeightG,
        commissionNote: draft.commissionNote,
        commissionerUserId: user.id
      });

      setReviewEntries((prev) =>
        prev.map((entry) =>
          entry.id === entryId
            ? {
                ...entry,
                ...updatedRow
              }
            : entry
        )
      );

      setCompetitionCatches((prev) =>
        prev.map((entry) =>
          entry.id === entryId
            ? {
                ...entry,
                ...updatedRow
              }
            : entry
        )
      );

      setReviewMessage("Fiche mise à jour.");
    } catch (error) {
      setReviewMessage(error.message || "Erreur lors de la sauvegarde.");
    } finally {
      setReviewSavingId("");
    }
  }

  /*
    MODIFICATION :
    action rapide : valider une ligne.
  */
  async function handleQuickValidate(entry) {
    if (!user?.id || !entry?.id || !entry?.catches) {
      return;
    }

    const quickDraft = {
      commissionStatus: "validated",
      commissionValidatedLengthCm:
        entry.commission_validated_length_cm ?? entry.catches.longueur_cm ?? "",
      commissionValidatedWeightG:
        entry.commission_validated_weight_g ?? entry.catches.poids_g ?? "",
      commissionNote: entry.commission_note || ""
    };

    setReviewDrafts((prev) => ({
      ...prev,
      [entry.id]: quickDraft
    }));

    try {
      setReviewSavingId(entry.id);
      setReviewMessage("");

      const updatedRow = await updateCompetitionCatchCommission({
        competitionCatchId: entry.id,
        commissionStatus: "validated",
        commissionValidatedLengthCm: quickDraft.commissionValidatedLengthCm,
        commissionValidatedWeightG: quickDraft.commissionValidatedWeightG,
        commissionNote: quickDraft.commissionNote,
        commissionerUserId: user.id
      });

      setReviewEntries((prev) =>
        prev.map((currentEntry) =>
          currentEntry.id === entry.id
            ? {
                ...currentEntry,
                ...updatedRow
              }
            : currentEntry
        )
      );

      setCompetitionCatches((prev) =>
        prev.map((currentEntry) =>
          currentEntry.id === entry.id
            ? {
                ...currentEntry,
                ...updatedRow
              }
            : currentEntry
        )
      );

      setReviewMessage("Prise validée.");
    } catch (error) {
      setReviewMessage(error.message || "Erreur lors de la sauvegarde.");
    } finally {
      setReviewSavingId("");
    }
  }

  /*
    MODIFICATION :
    action rapide : refuser une ligne.
  */
  async function handleQuickReject(entry) {
    if (!user?.id || !entry?.id) {
      return;
    }

    const quickDraft = {
      commissionStatus: "rejected",
      commissionValidatedLengthCm: "",
      commissionValidatedWeightG: "",
      commissionNote: entry.commission_note || ""
    };

    setReviewDrafts((prev) => ({
      ...prev,
      [entry.id]: quickDraft
    }));

    try {
      setReviewSavingId(entry.id);
      setReviewMessage("");

      const updatedRow = await updateCompetitionCatchCommission({
        competitionCatchId: entry.id,
        commissionStatus: "rejected",
        commissionValidatedLengthCm: null,
        commissionValidatedWeightG: null,
        commissionNote: quickDraft.commissionNote,
        commissionerUserId: user.id
      });

      setReviewEntries((prev) =>
        prev.map((currentEntry) =>
          currentEntry.id === entry.id
            ? {
                ...currentEntry,
                ...updatedRow
              }
            : currentEntry
        )
      );

      setCompetitionCatches((prev) =>
        prev.map((currentEntry) =>
          currentEntry.id === entry.id
            ? {
                ...currentEntry,
                ...updatedRow
              }
            : currentEntry
        )
      );

      setReviewMessage("Prise refusée.");
    } catch (error) {
      setReviewMessage(error.message || "Erreur lors de la sauvegarde.");
    } finally {
      setReviewSavingId("");
    }
  }

  /*
    MODIFICATION :
    action rapide : préparer une correction automatique
    en basculant juste le statut sur "corrected".
  */
  function handleQuickPrepareCorrection(entry) {
    if (!entry?.id) {
      return;
    }

    setReviewDrafts((prev) => ({
      ...prev,
      [entry.id]: {
        ...buildCommissionDraft(entry),
        commissionStatus: "corrected"
      }
    }));
  }

  /*
    MODIFICATION :
    validation en masse des prises en attente.
  */
  async function handleValidateAllPending() {
    try {
      if (!user?.id) {
        return;
      }

      const pendingEntries = reviewEntries.filter(
        (entry) => entry.commission_status === "pending" && entry.catches
      );

      if (pendingEntries.length === 0) {
        setReviewMessage("Aucune prise en attente à valider.");
        return;
      }

      setReviewSavingId("bulk_pending");
      setReviewMessage("");

      const updatedRows = await Promise.all(
        pendingEntries.map((entry) =>
          updateCompetitionCatchCommission({
            competitionCatchId: entry.id,
            commissionStatus: "validated",
            commissionValidatedLengthCm:
              entry.commission_validated_length_cm ??
              entry.catches?.longueur_cm ??
              null,
            commissionValidatedWeightG:
              entry.commission_validated_weight_g ??
              entry.catches?.poids_g ??
              null,
            commissionNote: entry.commission_note || "",
            commissionerUserId: user.id
          })
        )
      );

      const updatedRowsMap = new Map(
        updatedRows.map((row) => [row.id, row])
      );

      setReviewEntries((prev) =>
        prev.map((entry) =>
          updatedRowsMap.has(entry.id)
            ? {
                ...entry,
                ...updatedRowsMap.get(entry.id)
              }
            : entry
        )
      );

      setCompetitionCatches((prev) =>
        prev.map((entry) =>
          updatedRowsMap.has(entry.id)
            ? {
                ...entry,
                ...updatedRowsMap.get(entry.id)
              }
            : entry
        )
      );

      setReviewDrafts((prev) => {
        const nextDrafts = { ...prev };

        pendingEntries.forEach((entry) => {
          nextDrafts[entry.id] = {
            commissionStatus: "validated",
            commissionValidatedLengthCm:
              entry.commission_validated_length_cm ??
              entry.catches?.longueur_cm ??
              "",
            commissionValidatedWeightG:
              entry.commission_validated_weight_g ??
              entry.catches?.poids_g ??
              "",
            commissionNote: entry.commission_note || ""
          };
        });

        return nextDrafts;
      });

      setReviewMessage("Toutes les prises en attente ont été validées.");
    } catch (error) {
      setReviewMessage(
        error.message || "Erreur lors de la validation en masse."
      );
    } finally {
      setReviewSavingId("");
    }
  }

  if (loading) {
    return (
      <section>
        <h2 className="page-title">Concours</h2>
        <p className="page-description">Chargement du concours...</p>
      </section>
    );
  }

  if (message) {
    return (
      <section>
        <h2 className="page-title">Concours</h2>
        <div className="card">
          <p className="card-text">{message}</p>
        </div>
      </section>
    );
  }

  return (
    <section>
      <h2 className="page-title">{competition?.name || "Détail concours"}</h2>
      <p className="page-description">
        Code : {competition?.code} | Créateur : {creatorName}
      </p>

      <div className="card">
        <p className="card-text">
          Début :{" "}
          {competition?.start_date
            ? new Date(competition.start_date).toLocaleString("fr-FR")
            : "Non défini"}
        </p>
        <p className="card-text">
          Fin :{" "}
          {competition?.end_date
            ? new Date(competition.end_date).toLocaleString("fr-FR")
            : "Non définie"}
        </p>
        <p className="card-text">
          Délai de saisie après la fin :{" "}
          {competition?.grace_period_minutes || 0} min
        </p>
        <p className="card-text">
          Date limite de saisie :{" "}
          {entryDeadline
            ? entryDeadline.toLocaleString("fr-FR")
            : "Non définie"}
        </p>
        <p className="card-text">Statut : {getStatusLabel()}</p>
      </div>

      {isHourlyVisibility ? (
        <div className="card">
          <p className="card-text">
            Les résultats de ce concours sont affichés avec une actualisation
            horaire.
          </p>
        </div>
      ) : null}

      {competition?.results_visibility === "hidden" &&
      !isCompetitionEntryClosed ? (
        <div className="card">
          <p className="card-text">
            Les résultats sont masqués jusqu’à la fin du concours et la fin du
            délai de saisie.
          </p>
        </div>
      ) : null}

      {canCreatorPublishResults ? (
        <div className="card">
          <h3 className="card-title">Publication des résultats</h3>
          <p className="card-text">
            Le concours est clôturé. En tant que créateur, tu peux maintenant
            publier les résultats.
          </p>

          <div style={{ marginTop: "12px" }}>
            <button
              type="button"
              className="primary-button"
              onClick={handlePublishResults}
              disabled={publishingResults}
            >
              {publishingResults ? "Publication..." : "Afficher les résultats"}
            </button>
          </div>
        </div>
      ) : null}

      <div className="stats-grid">
        <div className="stat-card">
          <p className="stat-card__label">Participants</p>
          <p className="stat-card__value">{stats.participantsCount}</p>
        </div>

        <div className="stat-card">
          <p className="stat-card__label">Captures</p>
          <p className="stat-card__value">{stats.totalCatches}</p>
        </div>

        <div className="stat-card">
          <p className="stat-card__label">Poids total</p>
          <p className="stat-card__value">{stats.totalWeight} g</p>
        </div>

        <div className="stat-card">
          <p className="stat-card__label">Plus grosse prise</p>
          <p className="stat-card__value">{stats.biggestCatch} g</p>
        </div>
      </div>

      {canShowResults ? (
        <>
          <div className="card">
            <h3 className="card-title">Classement</h3>

            <div className="form" style={{ marginBottom: "16px" }}>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label" htmlFor="ranking-filter-sexe">
                    Sexe
                  </label>
                  <select
                    id="ranking-filter-sexe"
                    className="form-select"
                    value={selectedSexe}
                    onChange={(event) => setSelectedSexe(event.target.value)}
                  >
                    <option value={ALL_FILTER_VALUE}>Tous</option>
                    {sexeOptions.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="form-group">
                  <label
                    className="form-label"
                    htmlFor="ranking-filter-categorie"
                  >
                    Catégorie
                  </label>
                  <select
                    id="ranking-filter-categorie"
                    className="form-select"
                    value={selectedCategorie}
                    onChange={(event) =>
                      setSelectedCategorie(event.target.value)
                    }
                  >
                    <option value={ALL_FILTER_VALUE}>Toutes</option>
                    {categorieOptions.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label className="form-label" htmlFor="ranking-filter-club">
                    Club
                  </label>
                  <select
                    id="ranking-filter-club"
                    className="form-select"
                    value={selectedClub}
                    onChange={(event) => setSelectedClub(event.target.value)}
                  >
                    <option value={ALL_FILTER_VALUE}>Tous les clubs</option>
                    {clubOptions.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="form-group" style={{ alignSelf: "end" }}>
                  <button
                    type="button"
                    className="secondary-button"
                    onClick={resetFilters}
                  >
                    Réinitialiser les filtres
                  </button>
                </div>
              </div>
            </div>

            {filteredRanking.length === 0 ? (
              <p className="card-text">
                Aucun participant ne correspond aux filtres sélectionnés.
              </p>
            ) : (
              <div className="simple-list">
                {filteredRanking.map((row) => (
                  <article key={row.userId} className="list-item">
                    <h4 className="list-item__title">
                      {row.rank}. {row.displayName}
                    </h4>
                    <p className="list-item__meta">Sexe : {row.sexe}</p>
                    <p className="list-item__meta">
                      Catégorie : {row.categorie}
                    </p>
                    <p className="list-item__meta">Club : {row.club}</p>
                    <p className="list-item__meta">
                      Poids total : {row.totalWeight} g
                    </p>
                    <p className="list-item__meta">
                      Nombre de poissons : {row.fishCount}
                    </p>
                    <p className="list-item__meta">
                      Plus grosse prise : {row.biggestCatch} g
                    </p>
                  </article>
                ))}
              </div>
            )}
          </div>

          <div className="card">
            <h3 className="card-title">Captures du concours</h3>

            {competitionCatches.length === 0 ? (
              <p className="card-text">
                Aucune capture n’est encore enregistrée dans ce concours.
              </p>
            ) : (
              <div className="simple-list">
                {competitionCatches.map((entry) => {
                  const catchData = entry.catches;

                  if (!catchData) {
                    return null;
                  }

                  const fisherName = getDisplayNameFromProfile(
                    entry.profiles,
                    competition?.participant_display_mode || "pseudo"
                  );

                  return (
                    <article key={entry.id} className="list-item">
                      {catchData.photo_url ? (
                        <img
                          src={catchData.photo_url}
                          alt={catchData.espece}
                          style={{
                            width: "100%",
                            maxHeight: "220px",
                            objectFit: "cover",
                            borderRadius: "12px",
                            marginBottom: "12px"
                          }}
                        />
                      ) : null}

                      <h4 className="list-item__title">{catchData.espece}</h4>
                      <p className="list-item__meta">Pêcheur : {fisherName}</p>
                      <p className="list-item__meta">
                        Longueur : {catchData.longueur_cm} cm
                      </p>
                      <p className="list-item__meta">
                        Poids : {catchData.poids_g} g
                      </p>
                      <p className="list-item__meta">
                        Date :{" "}
                        {new Date(catchData.date_heure).toLocaleString("fr-FR")}
                      </p>
                      <p className="list-item__meta">
                        Zone : {catchData.zone_bareme}
                      </p>
                      <p className="list-item__meta">
                        Commentaire : {catchData.commentaire || "Aucun"}
                      </p>
                      <p className="list-item__meta">
                        Statut commissaire :{" "}
                        {getCommissionStatusLabel(entry.commission_status)}
                      </p>
                    </article>
                  );
                })}
              </div>
            )}
          </div>
        </>
      ) : (
        <div className="card">
          <h3 className="card-title">Résultats</h3>
          <p className="card-text">
            Les résultats de ce concours sont actuellement masqués.
          </p>
        </div>
      )}

      {isCreator ? (
        <div className="card">
          <h3 className="card-title">Vérification des fiches participants</h3>

          <div className="form">
            <div className="form-group">
              <label className="form-label" htmlFor="review-participant-select">
                Choisir un participant
              </label>
              <select
                id="review-participant-select"
                className="form-select"
                value={selectedParticipantId}
                onChange={(event) => setSelectedParticipantId(event.target.value)}
              >
                <option value="">Choisir un participant</option>
                {reviewParticipantOptions.map((participant) => (
                  <option key={participant.userId} value={participant.userId}>
                    {participant.displayName} — {participant.categorie} —{" "}
                    {participant.club}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {reviewLoading ? (
            <p className="card-text">Chargement de la fiche participant...</p>
          ) : null}

          {reviewMessage ? <p className="card-text">{reviewMessage}</p> : null}

          {reviewParticipantProfile ? (
            <>
              <div className="card" style={{ marginBottom: "16px" }}>
                <h4 className="card-title">
                  {getDisplayNameFromProfile(
                    reviewParticipantProfile,
                    competition?.participant_display_mode || "pseudo"
                  )}
                </h4>
                <p className="card-text">
                  Sexe : {reviewParticipantProfile.sexe || "—"}
                </p>
                <p className="card-text">
                  Catégorie : {reviewParticipantProfile.categorie || "—"}
                </p>
                <p className="card-text">
                  Club : {reviewParticipantProfile.club || "—"}
                </p>
              </div>

              {/* MODIFICATION :
                  fiche officielle type commissaire 2022
              */}
              <div className="card" style={{ marginBottom: "16px" }}>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    gap: "12px",
                    alignItems: "center",
                    flexWrap: "wrap",
                    marginBottom: "16px"
                  }}
                >
                  <h4 className="card-title" style={{ margin: 0 }}>
                    Fiche officielle commissaire
                  </h4>

                  <button
                    type="button"
                    className="secondary-button"
                    onClick={() => window.print()}
                  >
                    Imprimer la fiche
                  </button>
                </div>

                <div
                  style={{
                    border: "1px solid #d8dee6",
                    borderRadius: "16px",
                    padding: "16px",
                    background: "#fff"
                  }}
                >
                  <div
                    style={{
                      display: "grid",
                      gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
                      gap: "12px",
                      marginBottom: "16px"
                    }}
                  >
                    <div
                      style={{
                        border: "1px solid #d8dee6",
                        borderRadius: "12px",
                        padding: "12px"
                      }}
                    >
                      <p className="card-text">
                        Concours du :{" "}
                        {competition?.start_date
                          ? new Date(competition.start_date).toLocaleDateString(
                              "fr-FR"
                            )
                          : "Non défini"}
                      </p>
                      <p className="card-text">
                        Organisé par : {creatorName || "Non renseigné"}
                      </p>
                    </div>

                    <div
                      style={{
                        border: "1px solid #d8dee6",
                        borderRadius: "12px",
                        padding: "12px",
                        textAlign: "center",
                        fontWeight: "700"
                      }}
                    >
                      FICHE COMMISSAIRE
                    </div>
                  </div>

                  <div
                    style={{
                      display: "grid",
                      gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
                      gap: "12px",
                      marginBottom: "16px"
                    }}
                  >
                    <div
                      style={{
                        border: "1px solid #d8dee6",
                        borderRadius: "12px",
                        padding: "12px"
                      }}
                    >
                      <p className="card-text">
                        Nom : {reviewParticipantProfile.nom || "—"}
                      </p>
                      <p className="card-text">
                        Prénom : {reviewParticipantProfile.prenom || "—"}
                      </p>
                      <p className="card-text">
                        Club : {reviewParticipantProfile.club || "—"}
                      </p>
                    </div>

                    <div
                      style={{
                        border: "1px solid #d8dee6",
                        borderRadius: "12px",
                        padding: "12px"
                      }}
                    >
                      <p className="card-text">
                        Catégorie : {reviewParticipantProfile.categorie || "—"}
                      </p>
                      <p className="card-text">
                        Place N° :{" "}
                        {reviewParticipantProfile.place_number || "—"}
                      </p>
                    </div>
                  </div>

                  <p
                    className="card-text"
                    style={{ textAlign: "center", fontWeight: 700 }}
                  >
                    Concours NO KILL, toutes les prises doivent être remises à
                    l&apos;eau
                  </p>
                  <p
                    className="card-text"
                    style={{ textAlign: "center", marginBottom: "12px" }}
                  >
                    Enregistrer ici les poissons (longueur en cm) au-delà de 15
                    cm
                  </p>

                  <div style={{ overflowX: "auto", marginBottom: "12px" }}>
                    <table
                      style={{
                        width: "100%",
                        borderCollapse: "collapse",
                        minWidth: "720px"
                      }}
                    >
                      <thead>
                        <tr>
                          <th
                            style={{
                              border: "1px solid #cfd8e3",
                              padding: "8px",
                              textAlign: "left"
                            }}
                          >
                            Espèce
                          </th>
                          <th
                            style={{
                              border: "1px solid #cfd8e3",
                              padding: "8px",
                              textAlign: "left"
                            }}
                          >
                            Longueurs enregistrées
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {officialSheetData.officialRows.map((row) => (
                          <tr key={row.label}>
                            <td
                              style={{
                                border: "1px solid #cfd8e3",
                                padding: "8px",
                                fontWeight: 700
                              }}
                            >
                              {row.label}
                            </td>
                            <td
                              style={{
                                border: "1px solid #cfd8e3",
                                padding: "8px"
                              }}
                            >
                              {row.lengths.length > 0
                                ? row.lengths.join(" • ")
                                : "—"}
                            </td>
                          </tr>
                        ))}

                        {officialSheetData.extraRows.length > 0
                          ? officialSheetData.extraRows.map((row) => (
                              <tr key={`extra-${row.label}`}>
                                <td
                                  style={{
                                    border: "1px solid #cfd8e3",
                                    padding: "8px",
                                    fontWeight: 700
                                  }}
                                >
                                  {row.label}
                                </td>
                                <td
                                  style={{
                                    border: "1px solid #cfd8e3",
                                    padding: "8px"
                                  }}
                                >
                                  {row.lengths.length > 0
                                    ? row.lengths.join(" • ")
                                    : "—"}
                                </td>
                              </tr>
                            ))
                          : null}

                        {/* MODIFICATION :
                            on garde quelques lignes vides pour rester proche
                            du modèle papier quand aucune espèce supplémentaire
                            n'est présente.
                        */}
                        {Array.from({
                          length: Math.max(0, 4 - officialSheetData.extraRows.length)
                        }).map((_, index) => (
                          <tr key={`blank-${index}`}>
                            <td
                              style={{
                                border: "1px solid #cfd8e3",
                                padding: "8px"
                              }}
                            >
                              &nbsp;
                            </td>
                            <td
                              style={{
                                border: "1px solid #cfd8e3",
                                padding: "8px"
                              }}
                            >
                              &nbsp;
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  <div
                    style={{
                      border: "1px solid #d8dee6",
                      borderRadius: "12px",
                      padding: "12px",
                      marginBottom: "12px"
                    }}
                  >
                    <p className="card-text" style={{ fontWeight: 700 }}>
                      GRANDE VIVE : ne pas mesurer, noter le nombre total
                    </p>
                    <p className="card-text">
                      Nombre : {officialSheetData.grandeViveCount}
                    </p>
                    <p className="card-text">
                      Forfait comptabilisé : {officialSheetData.grandeViveWeight} g
                    </p>
                  </div>

                  <div
                    style={{
                      border: "1px solid #d8dee6",
                      borderRadius: "12px",
                      padding: "12px",
                      marginBottom: "12px"
                    }}
                  >
                    <p className="card-text" style={{ fontWeight: 700 }}>
                      Poissons mesurés à moins de 15 cm
                    </p>

                    {officialSheetData.under15Rows.length === 0 ? (
                      <p className="card-text">Aucun poisson sous 15 cm.</p>
                    ) : (
                      <div style={{ overflowX: "auto" }}>
                        <table
                          style={{
                            width: "100%",
                            borderCollapse: "collapse",
                            minWidth: "480px"
                          }}
                        >
                          <thead>
                            <tr>
                              <th
                                style={{
                                  border: "1px solid #cfd8e3",
                                  padding: "8px",
                                  textAlign: "left"
                                }}
                              >
                                Espèce
                              </th>
                              <th
                                style={{
                                  border: "1px solid #cfd8e3",
                                  padding: "8px",
                                  textAlign: "left"
                                }}
                              >
                                Nombre
                              </th>
                              <th
                                style={{
                                  border: "1px solid #cfd8e3",
                                  padding: "8px",
                                  textAlign: "left"
                                }}
                              >
                                Poids total
                              </th>
                            </tr>
                          </thead>
                          <tbody>
                            {officialSheetData.under15Rows.map((row) => (
                              <tr key={`under15-${row.label}`}>
                                <td
                                  style={{
                                    border: "1px solid #cfd8e3",
                                    padding: "8px"
                                  }}
                                >
                                  {row.label}
                                </td>
                                <td
                                  style={{
                                    border: "1px solid #cfd8e3",
                                    padding: "8px"
                                  }}
                                >
                                  {row.count}
                                </td>
                                <td
                                  style={{
                                    border: "1px solid #cfd8e3",
                                    padding: "8px"
                                  }}
                                >
                                  {row.totalWeight} g
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>

                  <div
                    style={{
                      display: "grid",
                      gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
                      gap: "12px",
                      marginBottom: "12px"
                    }}
                  >
                    <div
                      style={{
                        border: "1px solid #d8dee6",
                        borderRadius: "12px",
                        padding: "12px"
                      }}
                    >
                      <p className="card-text">
                        Poissons mesurés : {officialSheetData.measuredCount}
                      </p>
                      <p className="card-text">
                        Poids : {officialSheetData.measuredWeight} g
                      </p>
                    </div>

                    <div
                      style={{
                        border: "1px solid #d8dee6",
                        borderRadius: "12px",
                        padding: "12px"
                      }}
                    >
                      <p className="card-text">
                        Poissons - 15 cm : {officialSheetData.under15Count}
                      </p>
                      <p className="card-text">
                        Poids : {officialSheetData.under15Weight} g
                      </p>
                    </div>

                    <div
                      style={{
                        border: "1px solid #d8dee6",
                        borderRadius: "12px",
                        padding: "12px"
                      }}
                    >
                      <p className="card-text">
                        Grandes vives : {officialSheetData.grandeViveCount}
                      </p>
                      <p className="card-text">
                        Valeur : {officialSheetData.grandeViveWeight} g
                      </p>
                    </div>

                    <div
                      style={{
                        border: "2px solid #111827",
                        borderRadius: "12px",
                        padding: "12px"
                      }}
                    >
                      <p className="card-text" style={{ fontWeight: 700 }}>
                        TOTAL : {officialSheetData.totalWeight} g
                      </p>
                      <p className="card-text">
                        Nombre de poissons : {officialSheetData.totalFishCount}
                      </p>
                    </div>
                  </div>

                  <div
                    style={{
                      display: "grid",
                      gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
                      gap: "12px"
                    }}
                  >
                    <div
                      style={{
                        border: "1px solid #d8dee6",
                        borderRadius: "12px",
                        padding: "12px"
                      }}
                    >
                      <p className="card-text">
                        Signature Commissaire : __________________
                      </p>
                    </div>

                    <div
                      style={{
                        border: "1px solid #d8dee6",
                        borderRadius: "12px",
                        padding: "12px"
                      }}
                    >
                      <p className="card-text">
                        Signature Pêcheur : __________________
                      </p>
                    </div>

                    <div
                      style={{
                        border: "1px solid #d8dee6",
                        borderRadius: "12px",
                        padding: "12px"
                      }}
                    >
                      <p className="card-text">
                        Plus gros poisson : {officialSheetData.biggestFishWeight} g
                      </p>
                    </div>

                    <div
                      style={{
                        border: "1px solid #d8dee6",
                        borderRadius: "12px",
                        padding: "12px"
                      }}
                    >
                      <p className="card-text">Classement : —</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="stats-grid">
                <div className="stat-card">
                  <p className="stat-card__label">Poissons validés</p>
                  <p className="stat-card__value">
                    {reviewOfficialSummary.totalFish}
                  </p>
                </div>

                <div className="stat-card">
                  <p className="stat-card__label">Poids officiel</p>
                  <p className="stat-card__value">
                    {reviewOfficialSummary.totalWeight} g
                  </p>
                </div>

                <div className="stat-card">
                  <p className="stat-card__label">Plus grosse prise</p>
                  <p className="stat-card__value">
                    {reviewOfficialSummary.biggestCatch} g
                  </p>
                </div>

                <div className="stat-card">
                  <p className="stat-card__label">En attente / Refusées</p>
                  <p className="stat-card__value">
                    {reviewOfficialSummary.pendingCount} /{" "}
                    {reviewOfficialSummary.rejectedCount}
                  </p>
                </div>
              </div>

              {/* MODIFICATION :
                  barre de contrôle rapide organisateur
              */}
              <div className="card" style={{ marginBottom: "16px" }}>
                <h4 className="card-title">Contrôle rapide</h4>

                <div className="form-row">
                  <div className="form-group">
                    <label
                      className="form-label"
                      htmlFor="review-status-filter"
                    >
                      Filtrer les prises
                    </label>
                    <select
                      id="review-status-filter"
                      className="form-select"
                      value={reviewStatusFilter}
                      onChange={(event) =>
                        setReviewStatusFilter(event.target.value)
                      }
                    >
                      {REVIEW_STATUS_FILTERS.map((option) => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="form-group" style={{ alignSelf: "end" }}>
                    <button
                      type="button"
                      className="primary-button"
                      onClick={handleValidateAllPending}
                      disabled={reviewSavingId === "bulk_pending"}
                    >
                      {reviewSavingId === "bulk_pending"
                        ? "Validation..."
                        : "Valider toutes les prises en attente"}
                    </button>
                  </div>
                </div>

                <p className="card-text">
                  Validées : {reviewOfficialSummary.validatedCount} | Corrigées :{" "}
                  {reviewOfficialSummary.correctedCount} | En attente :{" "}
                  {reviewOfficialSummary.pendingCount} | Refusées :{" "}
                  {reviewOfficialSummary.rejectedCount}
                </p>
              </div>

              <div className="simple-list">
                {filteredReviewEntries.length === 0 ? (
                  <p className="card-text">
                    Aucune prise ne correspond au filtre sélectionné.
                  </p>
                ) : (
                  filteredReviewEntries.map((entry) => {
                    const catchData = entry.catches;

                    if (!catchData) {
                      return null;
                    }

                    const draft =
                      reviewDrafts[entry.id] || buildCommissionDraft(entry);

                    const officialMetrics = getOfficialCatchMetrics({
                      ...entry,
                      commission_status: draft.commissionStatus,
                      commission_validated_length_cm:
                        draft.commissionValidatedLengthCm,
                      commission_validated_weight_g:
                        draft.commissionValidatedWeightG
                    });

                    return (
                      <article key={entry.id} className="list-item">
                        {/* MODIFICATION :
                            zone compacte avec actions rapides
                        */}
                        <div
                          style={{
                            display: "flex",
                            justifyContent: "space-between",
                            gap: "12px",
                            flexWrap: "wrap",
                            marginBottom: "12px"
                          }}
                        >
                          <div>
                            <h4 className="list-item__title">
                              {catchData.espece}
                            </h4>
                            <p className="list-item__meta">
                              Longueur saisie : {catchData.longueur_cm} cm
                            </p>
                            <p className="list-item__meta">
                              Poids saisi : {catchData.poids_g} g
                            </p>
                            <p className="list-item__meta">
                              Date :{" "}
                              {new Date(catchData.date_heure).toLocaleString(
                                "fr-FR"
                              )}
                            </p>
                            <p className="list-item__meta">
                              Statut actuel :{" "}
                              {getCommissionStatusLabel(
                                entry.commission_status
                              )}
                            </p>

                            {officialMetrics ? (
                              <p className="list-item__meta">
                                Valeur officielle en cours :{" "}
                                {officialMetrics.longueurCm} cm /{" "}
                                {officialMetrics.poidsG} g
                              </p>
                            ) : (
                              <p className="list-item__meta">
                                Valeur officielle en cours : prise refusée
                              </p>
                            )}
                          </div>

                          <div
                            style={{
                              display: "flex",
                              gap: "8px",
                              alignItems: "flex-start",
                              flexWrap: "wrap"
                            }}
                          >
                            <button
                              type="button"
                              className="secondary-button"
                              onClick={() => handleQuickValidate(entry)}
                              disabled={reviewSavingId === entry.id}
                              title="Valider rapidement"
                            >
                              ✅ Valider
                            </button>

                            <button
                              type="button"
                              className="secondary-button"
                              onClick={() => handleQuickPrepareCorrection(entry)}
                              disabled={reviewSavingId === entry.id}
                              title="Préparer une correction"
                            >
                              ✏️ Corriger
                            </button>

                            <button
                              type="button"
                              className="secondary-button"
                              onClick={() => handleQuickReject(entry)}
                              disabled={reviewSavingId === entry.id}
                              title="Refuser rapidement"
                            >
                              ❌ Refuser
                            </button>
                          </div>
                        </div>

                        <div className="form" style={{ marginTop: "12px" }}>
                          <div className="form-group">
                            <label className="form-label">
                              Décision organisateur
                            </label>
                            <select
                              className="form-select"
                              value={draft.commissionStatus}
                              onChange={(event) =>
                                handleReviewDraftChange(
                                  entry.id,
                                  "commissionStatus",
                                  event.target.value
                                )
                              }
                            >
                              <option value="pending">En attente</option>
                              <option value="validated">Valider</option>
                              <option value="corrected">Corriger</option>
                              <option value="rejected">Refuser</option>
                            </select>
                          </div>

                          <div className="form-row">
                            <div className="form-group">
                              <label className="form-label">
                                Longueur validée (cm)
                              </label>
                              <input
                                className="form-input"
                                type="number"
                                value={draft.commissionValidatedLengthCm}
                                onChange={(event) =>
                                  handleReviewDraftChange(
                                    entry.id,
                                    "commissionValidatedLengthCm",
                                    event.target.value
                                  )
                                }
                              />
                            </div>

                            <div className="form-group">
                              <label className="form-label">
                                Poids validé (g)
                              </label>
                              <input
                                className="form-input"
                                type="number"
                                value={draft.commissionValidatedWeightG}
                                onChange={(event) =>
                                  handleReviewDraftChange(
                                    entry.id,
                                    "commissionValidatedWeightG",
                                    event.target.value
                                  )
                                }
                              />
                            </div>
                          </div>

                          <div className="form-group">
                            <label className="form-label">
                              Note organisateur
                            </label>
                            <textarea
                              className="form-textarea"
                              value={draft.commissionNote}
                              onChange={(event) =>
                                handleReviewDraftChange(
                                  entry.id,
                                  "commissionNote",
                                  event.target.value
                                )
                              }
                            />
                          </div>

                          <button
                            type="button"
                            className="primary-button"
                            onClick={() => handleSaveCommission(entry.id)}
                            disabled={reviewSavingId === entry.id}
                          >
                            {reviewSavingId === entry.id
                              ? "Enregistrement..."
                              : "Enregistrer la décision"}
                          </button>
                        </div>
                      </article>
                    );
                  })
                )}
              </div>
            </>
          ) : null}
        </div>
      ) : null}

      <div className="card">
        <Link
          to="/captures/ajouter"
          className="primary-button"
          style={{
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            width: "100%"
          }}
        >
          Ajouter une capture à un concours
        </Link>
      </div>
    </section>
  );
}