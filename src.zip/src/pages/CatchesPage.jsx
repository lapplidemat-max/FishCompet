import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { deleteCatch, fetchUserCatches } from "../services/catches";

/*
  MODIFICATION :
  Cette page lit maintenant les vraies captures depuis Supabase.
  Ajouts :
  - chargement réel
  - affichage photo si disponible
  - suppression d'une capture
*/

export default function CatchesPage() {
  const navigate = useNavigate();
  const { user } = useAuth();

  const [catches, setCatches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");

  async function loadCatches() {
    try {
      if (!user?.id) {
        return;
      }

      setLoading(true);
      const data = await fetchUserCatches(user.id);
      setCatches(data);
    } catch (error) {
      setMessage(error.message || "Erreur lors du chargement des captures.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadCatches();
  }, [user?.id]);

  async function handleDelete(catchId) {
    const confirmed = window.confirm(
      "Voulez-vous vraiment supprimer cette capture ?"
    );

    if (!confirmed) {
      return;
    }

    try {
      await deleteCatch(catchId, user.id);
      await loadCatches();
    } catch (error) {
      setMessage(error.message || "Erreur lors de la suppression.");
    }
  }

  return (
    <section>
      <h2 className="page-title">Mes captures</h2>
      <p className="page-description">
        Liste réelle des captures enregistrées dans Supabase.
      </p>

      <div className="card">
        <button
          className="primary-button"
          onClick={() => navigate("/captures/ajouter")}
        >
          Ajouter une capture
        </button>
      </div>

      {message ? (
        <div className="card">
          <p className="card-text">{message}</p>
        </div>
      ) : null}

      {loading ? (
        <div className="card">
          <p className="card-text">Chargement des captures...</p>
        </div>
      ) : catches.length === 0 ? (
        <div className="card empty-state">
          <h3 className="empty-state__title">Aucune capture</h3>
          <p className="empty-state__text">
            Commence par enregistrer ta première prise.
          </p>
        </div>
      ) : (
        <div className="simple-list">
          {catches.map((catchItem) => (
            <article key={catchItem.id} className="list-item">
              {catchItem.photo_url ? (
                <img
                  src={catchItem.photo_url}
                  alt={catchItem.espece}
                  style={{
                    width: "100%",
                    maxHeight: "220px",
                    objectFit: "cover",
                    borderRadius: "12px",
                    marginBottom: "12px"
                  }}
                />
              ) : null}

              <h3 className="list-item__title">{catchItem.espece}</h3>
              <p className="list-item__meta">
                Longueur : {catchItem.longueur_cm} cm
              </p>
              <p className="list-item__meta">
                Poids :{" "}
                {catchItem.poids_g !== null
                  ? `${catchItem.poids_g} g`
                  : "En attente du barème complet"}
              </p>
              <p className="list-item__meta">
                Zone : {catchItem.zone_bareme}
              </p>
              <p className="list-item__meta">
                Date : {new Date(catchItem.date_heure).toLocaleString("fr-FR")}
              </p>
              <p className="list-item__meta">
                Commentaire : {catchItem.commentaire || "Aucun"}
              </p>

              <div style={{ marginTop: "12px" }}>
                <button
                  type="button"
                  className="secondary-button"
                  onClick={() => handleDelete(catchItem.id)}
                >
                  Supprimer
                </button>
              </div>
            </article>
          ))}
        </div>
      )}
    </section>
  );
}