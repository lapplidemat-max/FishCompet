import { Outlet, useNavigate } from "react-router-dom";
import BottomNav from "./BottomNav";
import { useAuth } from "../context/AuthContext";

/*
  MODIFICATION :
  Ajout du bouton de déconnexion.
*/

export default function AppLayout() {
  const navigate = useNavigate();
  const { signOut, profile, user } = useAuth();

  async function handleLogout() {
    try {
      await signOut();
      navigate("/connexion", { replace: true });
    } catch (error) {
      alert(error.message || "Erreur lors de la déconnexion.");
    }
  }

  return (
    <div className="app-shell">
      <header className="app-header">
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            gap: "12px",
            alignItems: "flex-start"
          }}
        >
          <div>
            <h1 className="app-header__title">L’appli de Mat</h1>
            <p className="app-header__subtitle">
              {profile?.pseudo
                ? `Connecté en tant que ${profile.pseudo}`
                : user?.email || "Utilisateur connecté"}
            </p>
          </div>

          <button
            type="button"
            className="secondary-button"
            onClick={handleLogout}
            style={{ width: "auto", minWidth: "120px" }}
          >
            Déconnexion
          </button>
        </div>
      </header>

      <main className="app-main">
        <Outlet />
      </main>

      <BottomNav />
    </div>
  );
}