/*
  MODIFICATION :
  Liste centralisée des clubs.
  Remplace ce tableau par la liste officielle complète de tes clubs.

  IMPORTANT :
  On garde ce fichier séparé pour pouvoir :
  - réutiliser les clubs ailleurs dans l'application
  - mettre à jour la liste facilement
  - éviter de dupliquer les données dans plusieurs composants
*/

export const CLUBS_OPTIONS = [
  "Aucun club",
  "Club de pêche de Bordeaux",
  "Club de pêche de Bayonne",
  "Club de pêche de Dax",
  "Club de pêche de Biscarrosse",
  "Club de pêche d’Arcachon",
  "Club de pêche de La Rochelle",
  "Club de pêche de Royan",
  "Club de pêche de Sète",
  "Club de pêche de Marseille"
].sort((a, b) => a.localeCompare(b, "fr"));